<div class="user-manage">
  <!-- <div class=""> -->
	<ul class="nav nav-tabs">
	  <li <?php echo $page==0?'class="active"':''?>>
	    <a href="<?= site_url('invite')?>">Invites You Sent</a>
	  </li>
	  <li <?php echo $page==1?'class="active"':''?>><a href="<?= site_url('invite/new')?>">New Invite</a></li>
	</ul>

	<div class="user-content">

	  
	</div>
  <!-- </div> -->
</div>