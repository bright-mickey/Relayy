<div class="section_wrapper container">
    <div class="post-text">
    	<h4>What We Offer</h4>
		<p>At Relayy, we’re creating software which changes the way social is defined and provide innovative new ways for users to share and connect with one another. Our philosophy on design is to create the best user experience while ensuring users are respected.</p>
		<p>Our goals are to develop the most comprehensive and high quality apps for free which will create a radical shift in the industry from high abuse from longstanding competitors who will be unable to adjust their position given their significant requirements for squeezing the last drop out of users to maximise advertising revenue while users are abandoning their software to go to better and more respectful companies.</p>
		<p>With an emphasis on excellent quality at no cost while maintaining complete privacy, here are a few of our products:</p>
		<h4>Where We Are</h4>
		<p>We’ve offices in Garner - North Carolina, USA. </p>
		<h4>Our Story</h4>
		<p>Founded in 2016, Relayy, Inc.</p> 
    </div>
</div>