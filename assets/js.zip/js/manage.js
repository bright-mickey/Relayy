$("#dropdown-invite").click(function(e){
		$("#dropdown-invite").addClass("open");
	});

	function AllUsers(){
		
		$.ajax({
	      url: site_url + 'users/allUsers',
	         data: {	           
	         },
	         success: function(data) {
	            $(".content").html(data);
	         },
	         type: 'POST'
     	});

	}

	function PendingUsers(){
		
		$.ajax({
	      url: site_url + 'users/pending',
	         data: {	           
	         },
	         success: function(data) {
	            $(".content").html(data);
	         },
	         type: 'POST'
     	});

	}

	function ActiveUsers(){
		
		$.ajax({
	      url: site_url + 'users/activated',
	         data: {	           
	         },
	         success: function(data) {
	            $(".content").html(data);
	         },
	         type: 'POST'
     	});

	}

	function InvitedUsers(){
		
		$.ajax({
	      url: site_url + 'users/invited',
	         data: {	           
	         },
	         success: function(data) {
	            $(".content").html(data);
	         },
	         type: 'POST'
     	});

	}

	function AllChats(){
		
		$.ajax({
	      url: site_url + 'allow/all',
	         data: {	           
	         },
	         success: function(data) {
	            $(".content").html(data);
	         },
	         type: 'POST'
     	});

	}

	function PendingChats(){
		
		$.ajax({
	      url: site_url + 'allow/pending',
	         data: {	           
	         },
	         success: function(data) {
	            $(".content").html(data);
	         },
	         type: 'POST'
     	});

	}

	function ActiveChats(){
		
		$.ajax({
	      url: site_url + 'allow/activated',
	         data: {	           
	         },
	         success: function(data) {
	            $(".content").html(data);
	         },
	         type: 'POST'
     	});

	}

	