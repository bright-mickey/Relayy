var QTitle;
var QContext;
var QTags=[];
var QWebLinks = [];
var QFileName=[];
var FirstDialog;
var SecondDialog;
var tag_review, link_review, htmlTxt;
var RouteUserIDArray=[];
var InitRouteUserIDArray=[];
var QuestionID;
var AcceptUserIDArray = [];
var RouterListDialog;

function AddTag(){
	   htmlTxt = '<li>'+ $("#tagname").val()+'<a class="close x" style="color:white;" onclick="tagRemove(this)">&times;</a></li>';
            $("#selected_tag").append(htmlTxt);

     QTags.push($("#tagname").val());
     $("#tagname").val("");
}

function AddLink(){
      if($("#web-link").val().indexOf("http://") < 0 && $("#web-link").val().indexOf("https://") < 0){
       alert("You must paste in a web link!");
       $("#web-link").val("");
       return;
      }
     htmlTxt = '<li>'+ $("#web-link").val()+'<a class="close x" style="color:white;" onclick="linkRemove(this)">&times;</a></li>';
            $("#selected_link").append(htmlTxt);

     QWebLinks.push($("#web-link").val());
     $("#web-link").val("");
}

function tagRemove(obj) {
    var strTxt = $(obj).parent().text();
    strTxt = strTxt.substring(0,strTxt.length-1);
    var index = QTags.indexOf(strTxt);
	  QTags.splice(index, 1);
    $(obj).parent().remove();
}

function linkRemove(obj) {
    var strTxt = $(obj).parent().text();
    strTxt = strTxt.substring(0,strTxt.length-1);
    var index = QWebLinks.indexOf(strTxt);
    QWebLinks.splice(index, 1);
    $(obj).parent().remove();
}

function searchStringInArray (str, strArray) {
    for (var j=0; j<strArray.length; j++) {
        if (strArray[j].match(str)) return j;
    }
    return -1;
}

function detect(e, object) {
    var key=e.keyCode || e.which;
    if (key==13){
        AddTag();
        
    }
}

function detect_link(e, object) {
    var key=e.keyCode || e.which;
    if (key==13){
        AddLink();
        
    }
}

var currentID;
function FirstQuestion(cid) {
    title = "ADD A QUESTION";
    currentID = cid;
    QTags=[];
    BootstrapDialog.show({
        type: BootstrapDialog.TYPE_PRIMARY,
        title: title,
        message: '<div id="channel_edit">'+
                  '<label class="d-label">'+
                    '<h5 style="margin-left:10px;">WHAT IS YOUR QUESTION?</h5>'+
                      '<input type="text" class="Qinput" placeholder="Type question here. You can add details on next page." id="title">'+
                  '</label>'+
                  '<ul id="selected_tag">'+
                      '</ul>'+
				          '<label class="d-label">'+
                    '<h5 style="margin-left:10px;">QUESTION TAGS</h5>'+
                      '<input type="text"  class="Qinput" placeholder="Add tags to ensure it gets to the most qualified advisors" id="tagname" onkeypress="detect(event, this)">'+
                      '<p class="padding_xs">Press Enter after each tag to add it to the tag list.</p>'+
                  '</label>'+
                  '</div>',
        buttons: [{
            label: 'NEXT',
            cssClass: 'AddQuestionbutton',
            icon: 'glyphicon glyphicon-chevron-right',
            autospin: true,                
            action: function(dialogRef) {  
              	QTitle = $("#title").val();

                if(QTitle === ""){
                  alert('Title is required');
                  return;
                } 
              	FirstDialog = dialogRef;
              	SecondQuestion();

            }
        }]
    });

}

function SecondQuestion() {
    title = "ADD A QUESTION";
    BootstrapDialog.show({
        type: BootstrapDialog.TYPE_PRIMARY,
        title: title,
        message: '<div id="channel_edit">'+
                  '<label class="d-label">'+
                    '<h5 style="margin-left:10px;">ADD SOME CONTEXT TO YOUR QUESTION</h5>'+
                      '<textarea  class="Qinput" maxlength="1000" style="width:100%;height:150px;" placeholder="The more context surrounding a question, the better the answer. Please type some details here..." id="context-data" autofocus></textarea>'+
                  '</label>'+
                  '<ul id="selected_link">'+
                      '</ul>'+
				  '<label class="d-label">'+
                    '<h5 style="margin-left:10px;">ADD WEBSITE LINK</h5>'+
                      '<input   class="Qinput" type="text" placeholder="Paste in a web link and hit Enter" id="web-link"  onkeypress="detect_link(event, this)">'+
                  '</label>'+
                  '<h5 style="margin-left:10px;">ADD FILES (png, jpg, gifs, pdf)</h5>'+
                  '<div id="add_file">'+  
                    '<div class="file-div">'+
                      '<form action="" class="load-img" method="POST" enctype="multipart/form-data">'+
                         '<input type="file" data-file="pp" class="Qinput pull-left addfile" name="FileName" onchange="uploadImage(this)"/>'+
                      '</form>'+
                      '<span class="pull-right big-button" onclick="deleteUploadFile(this);" style="margin:15px 5px;">&times;</span>'+
                    '</div>'+
                  '</div>'+
                  '</div>',
        buttons: [{
            label: 'PREVIOUS',
            cssClass: 'AddQuestionbutton gray',
            icon: 'glyphicon glyphicon-chevron-left',
            autospin: true,                
            action: function(dialogRef) {  
              	var QTitle = $("#title").val();
              	dialogRef.close();
            }
        },{
            label: 'NEXT',
            cssClass: 'AddQuestionbutton',
            icon: 'glyphicon glyphicon-chevron-right',
            autospin: true,                
            action: function(dialogRef) {  
                QContext = $("#context-data").val();
              	SecondDialog = dialogRef;
                $.ajax({
                   url: site_url + 'questions/add',
                   data: {
                      fname:JSON.stringify(QFileName),
                      title: QTitle,
                      context: QContext,
                      tags: JSON.stringify(QTags),
                      link: JSON.stringify(QWebLinks),
                      status: 0,//QUESTION_STATUS_DRAFT
                   },
                   success: function(data) {
                      FinalQuestion();
                   },
                   type: 'POST'
                });           	
            }
        }]
    });
    QFileName = [];
    
}

function deleteUploadFile(obj){
  var item = $(obj).parent().find("input").data("file");
  var index = QFileName.indexOf(item);
  QFileName.splice(index, 1);
  $(obj).parent().remove();
}

function uploadImage(obj) { 
    // select the form and submit
    var data = new FormData($(obj).parent()[0]);
    $(obj).parent().parent().parent().append('<p class="pull-right">Uploading...</p>');   
        
        $.ajax({
                 type:"POST",
                 url:site_url + 'questions/fileupload',
                 data:data,
                 mimeType: "multipart/form-data",
                  contentType: false,
                  cache: false,
                  processData: false,
                  success:function(data)
                  {
                        $(obj).parent().parent().parent().find('p').remove();
                        MoreFile();
                        QFileName.push(data); 
                        $(obj).attr("data-file", data);  
                  }
    }); 
}

function MoreFile(){
  var htm = '<div class="file-div">'+
                      '<form action="" class="load-img" method="POST" enctype="multipart/form-data">'+
                         '<input type="file" data-file="pp" class="Qinput pull-left addfile" name="FileName" onchange="uploadImage(this)"/>'+
                      '</form>'+
                      '<span class="pull-right big-button" onclick="deleteUploadFile(this);" style="margin:15px 5px;">&times;</span>'+
                    '</div>';
  $("#add_file").append(htm);
};



function FinalQuestion() {
    title = "VIEW DRAFT QUESTION";
    tag_review = "";
    for(var index in QTags){
      tag_review = tag_review + '<li>'+ QTags[index] + '</li>';      
    }

    link_review = "";
    for(var index in QWebLinks){
      link_review = link_review + '<p><a href="' + QWebLinks[index] + '">' + QWebLinks[index] + '</a></p>';      
    }

    file_review = "";
    var spary, ext;
    var imageExts=[];
    for(var index in QFileName){
      spary = QFileName[index].split(".");
      ext = spary[spary.length - 1] ;
      imageExts = ["png", "jpg", "jpeg", "PNG", "JPG", "JPEG"];
      if(imageExts.indexOf(ext)>=0){
         file_review = file_review + '<img class="preview-Img line-item" src="'+ 'uploads/'+QFileName[index]+'">';  
      }
      else if(ext === "pdf"){         
        file_review = file_review + '<img class="preview-Img line-item" src="'+ site_url + "assets/images/pdf.jpg" + '">';  
      }
      else if(ext === "gif"){
        file_review = file_review + '<img class="preview-Img line-item" src="'+ site_url + "assets/images/gifs.jpg" + '">';  
      }
      else{
        file_review = file_review + '<img class="preview-Img line-item" src="'+ site_url + "assets/images/file.jpg" + '">';  
      }
      
    }
    BootstrapDialog.show({
        type: BootstrapDialog.TYPE_PRIMARY,
        title: title,
        message: '<div id="channel_edit">'+
                  '<label class="d-label">'+
                    '<h5 style="margin-left:10px;">YOUR QUESTION</span>'+
                    '<h6  class="Qinput" style="margin-left:30px;color=#999;">' + QTitle + '</h6>'+
                  '</label>'+

                  '<ul id="selected_tag" class="padding_md">'+
                  tag_review +
                  '</ul>'+

				          '<label class="d-label">'+
                    '<h5 style="margin-left:10px;">CONTEXT DATA</h5>'+
                    '<h6 class="Qinput" style="margin-left:30px;color=#999;">' + QContext + '</h6>'+
                  '</label>'+
                  '<label class="d-label">'+
                    '<h5 style="margin-left:10px;">WEBSITE LINK</h5>'+
                  '</label>'+
                  '<ul id="" class="padding_md">'+
                  link_review +
                  '</ul>'+
                  '<label class="d-label">'+
                    '<h5 style="margin-left:10px;">ATTACHED FILE:</h5>'+
                    '<ul id="selected_tag" class="padding_md">'+
                      file_review +
                    '</ul>'+
                  '</label>'+
                  '</div>',
        buttons: [{
            label: 'PREVIOUS',
            cssClass: 'AddQuestionbutton gray',
            icon: 'glyphicon glyphicon-chevron-left',
            autospin: true,                
            action: function(dialogRef) {  
              	dialogRef.close();
            }
        },{
            label: 'SUBMIT',
            cssClass: 'AddQuestionbutton',
            icon: 'glyphicon glyphicon-chevron-right',
            autospin: true,                
            action: function(dialogRef) {  
              	QTitle = $("#title").val();
              	FirstDialog.close();
              	SecondDialog.close();
              	SubmitQuestion();
              	dialogRef.close();
            }
        }]
    });

    
    
    
}

function SubmitQuestion(){
        $.ajax({
           url: site_url + 'questions/submit',
           data: {             
              title: QTitle,
              context: QContext              
           },
           success: function(data) {
              location.reload();
           },
           type: 'POST'
        });

    
}

function list_questions(){
  $.ajax({
        url: site_url + 'questions/load_question_list',
           data: {
              
           },
           success: function(data) {
              $(".content").html(data);
           },
           type: 'POST'
        });
}

function callme(time) {

        if($("#"+time).val() === "HIDE DETAILS") {
            $("#"+time).val("VIEW DETAILS");
            $("."+time).hide();
        } else {
            $("#"+time).val("HIDE DETAILS");
            $("."+time).show();
        }        
    
};

function viewFeedDetail(){
   if($(".feed_question").val() === "HIDE DETAILS") {
            $(".feed_question").val("VIEW DETAILS");
            $(".feed_question").hide();
        } else {
            $(".feed_question").val("HIDE DETAILS");
            $(".feed_question").show();
        }    
}

function RouteQuestion(id){
  QuestionID = id;
  $.ajax({
      url: site_url + 'questions/RouteQuestion',
         data: {
            id:id
         },
         success: function(data) {
            $(".question-container").html(data);
         },
         type: 'POST'
      });

}



function onCheck(id){
  var index = RouteUserIDArray.indexOf(id);
  if(index == -1){
    RouteUserIDArray.push(id);
  }else{
    RouteUserIDArray.splice(index, 1);
  }
  
  if(RouteUserIDArray.length != InitRouteUserIDArray.length) $("#selected_advisor_num").text("You selected  " + (RouteUserIDArray.length - InitRouteUserIDArray.length).toString() + "  advisors");
  else{
    $("#selected_advisor_num").text("You selected nothing.");
    $(".select-all").prop('checked', false);
  } 
}

function onRoute(){

  if(JSON.stringify(RouteUserIDArray) === JSON.stringify(InitRouteUserIDArray)){
    alert('you selected nothing!');
    return;
  }
  $.ajax({
      url: site_url + 'questions/SubmitRoute',
         data: {
            q_id: QuestionID,
            r_ids: RouteUserIDArray
         },
         success: function(data) {
            location.href = site_url + 'questions';
         },
         type: 'POST'
      });
}

function selectAll(){
  if(!$(".select-all").prop('checked')){// unselect all
    RouteUserIDArray = JSON.parse(JSON.stringify(InitRouteUserIDArray))
    $('input:checkbox.select-checkbox').prop('checked', false);
  }
  else{// select all    
    $('input:checkbox.select-checkbox').prop('checked', true);
    $('input:checkbox.select-checkbox').each(function(){
      var index = RouteUserIDArray.indexOf(parseInt($(this).val()));
      if($(this).css('display') === 'block' && index == -1){
        RouteUserIDArray.push(parseInt($(this).val())); 
      }
    });
  }
  if(RouteUserIDArray.length != InitRouteUserIDArray.length) $("#selected_advisor_num").text("You selected  " + (RouteUserIDArray.length - InitRouteUserIDArray.length).toString() + "  advisors");
  else $("#selected_advisor_num").text("You selected nothing.");

}

function onAdvisorSearch(){

  $(".advisor_contacts").each(function(){
    if($(this).find('span:first').text().toLowerCase().indexOf($("#advisor_name").val().toLowerCase()) >=0 && $(this).attr('data-skills').toLowerCase().indexOf($("#advisor_skill").val().toLowerCase()) >=0){
      $(this).css('display', 'block');
    }
    else{
      $(this).css('display', 'none');
    }
  

  });
}



function deleteRouter(d_id){   
  

  BootstrapDialog.show({
        type: BootstrapDialog.TYPE_PRIMARY,
        title: 'Warnning',
        message: 'Are you sure to delete this user?',
        buttons: [{
            label: 'Cancel',
            cssClass: 'btn-primary',
            action: function(dialogRef) {  
                dialogRef.close();
            }
        },{
            label: 'Yes',
            cssClass: 'btn-primary',
            action: function(dialogRef) {  
                var index = AcceptUserIDArray.indexOf(d_id.toString());
                  if(index > -1) AcceptUserIDArray.splice(index, 1);
                  alert(QuestionID);
                  $.ajax({
                    url: site_url + 'questions/deleteRouter',
                       data: {
                          q_id: QuestionID,
                          r_ids: JSON.stringify(AcceptUserIDArray)
                       },
                       success: function(data) {
                          // dialogRef.close();
                          // RouterListDialog.close();
                          // list_questions();
                          location.reload();
                       },
                       type: 'POST'
                    });
                
            }
        }]
  });
}

function getRouterUsers(email, callback) {
    $.ajax({
       url: site_url + 'chat/users',
       data: {
          email: email
       },
       success: function(data) {
          var jsonObj = JSON.parse(data);
          // if (email == '' && chatusers.length == 0) chatusers = jsonObj;
          console.log(jsonObj);
          callback(jsonObj);
       },
       type: 'POST'
    });
}

function buildRoutersHTML(json, email, str_r_ids, q_id) {

  AcceptUserIDArray = str_r_ids.split(" ");
    $("#routed-contacts").html("");
    if (json.length == 0 && email) {
        json.push({email:email, fname:"", lname:"", photo:"", uid:""});
    }
    json.forEach(function(item, index) {
        // console.log("#####################");
        // console.log(item);
        var userName = item.fname+' '+item.lname;
        if (userName.trim() == '') {
            var nameArr = item.email.split('@');
            userName = nameArr[0];
        }
        var index = AcceptUserIDArray.indexOf(item.id);
        if (index == -1) return;
        var htmlTxt;
        if(currentUser_type == 1) htmlTxt = '<li style="padding:10px;border-bottom: 1px solid #eee;"><span onclick="deleteRouter(' + item.id + ')" class="glyphicon glyphicon-trash pull-right text-primary"></span>';
        else htmlTxt = '<li style="padding:10px;border-bottom: 1px solid #eee;">';         
        if (item.photo) htmlTxt += '<img class="avatar avatar_small" src="'+item.photo+'">';
        htmlTxt = htmlTxt +       '<span class="contacts_name">'+userName+'</span>'+                        
                    '</li>';
        // alert(htmlTxt);
        $("#routed-contacts").append(htmlTxt);
    });
}

function viewRouteList(q_id, title, str_r_ids){
  QuestionID = q_id;
  RouterListDialog = BootstrapDialog.show({
        type: BootstrapDialog.TYPE_PRIMARY,
        title: 'ROUTE LIST of "'+ title + '"',
        message: '<div id="channel_edit">'+                      
                      '<ul id="routed-contacts" style="height:40vh;">'+ 
                                           
                      '</ul>'+
                 '</div>',
        buttons: [{
            label: 'Close',
            cssClass: 'btn-primary',
            action: function(dialogRef) {  
                dialogRef.close();
            }
        }]
  });
  getRouterUsers('', function(data) {
      buildRoutersHTML(data, '',str_r_ids, q_id);
  });
}

function viewWaitingList(q_id, title, str_a_ids){
  RouterListDialog = BootstrapDialog.show({
        type: BootstrapDialog.TYPE_PRIMARY,
        title: 'Waiting Advisors of "'+ title + '"',
        message: '<div id="channel_edit">'+                      
                      '<ul id="routed-contacts" style="height:40vh;">'+ 
                                           
                      '</ul>'+
                 '</div>',
        buttons: [{
            label: 'Close',
            cssClass: 'btn-primary',
            action: function(dialogRef) {  
                dialogRef.close();
            }
        }]
  });
  getRouterUsers('', function(data) {
      buildRoutersHTML(data, '',str_a_ids, q_id);
  });
}

function passFeed(q_id, c_id, b_accept, body_class){
  if(!b_accept) $("#pass-spinner").show();
	var index = router_ids.indexOf(c_id);
	if(index > -1)router_ids.splice(index, 1);
  if(b_accept && accept_ids.indexOf(c_id) < 0){
    accept_ids.push(c_id);
  } 
    $.ajax({
      url: site_url + 'questions/nextFeed',
         data: {
            q_id: q_id,
            r_ids: JSON.stringify(router_ids),
            a_ids: JSON.stringify(accept_ids),
            b_accept: b_accept
         },
         success: function(data) {
            if(body_class === "question-feed") location.href = site_url + "questions";
            else $(".content").html(data);
            $("#pass-spinner").hide();
         },
         type: 'POST'
      });
}

function acceptFeed(asker_email, asker_uid, c_id, q_id, title){
	var params = {
		type: 2,
		name: "Group"
	};
  $("#join-spinner").show();

	    $.ajax({
         url: site_url + 'questions/AcceptQuestion',
         data: {
            q_id: q_id,
            accepter_id: c_id,
         },
         success: function(data) {
            passFeed(q_id, c_id, true);   
            
         },
         type: 'POST'
      });



		                         
		 
}





function viewFeed(){
  
}

