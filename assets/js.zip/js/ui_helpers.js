// build html for messages localStorage.getItem('my_name')
function buildMessageHTML(messageSenderId, messageText, messageSenderName, messageSenderPic, messageDateSent, attachmentFileId, messageId, AttachmentFileName, AttachmentFileSize){
  var messageAttach;
  // target="_blank" download="download"
  if(attachmentFileId){    
      messageAttach ='<a href="http://api.quickblox.com/blobs/'+attachmentFileId+'/download.xml?token='+token+'" style="color:#111;">' + 
       '<img src="http://api.quickblox.com/blobs/'+attachmentFileId+'/download.xml?token='+token+'" alt="' + AttachmentFileName + '" class="attachments img-responsive /"></a>';
       var htm;
      var spary = AttachmentFileName.split(".");
      var ext = spary[spary.length - 1] ;
      var imageExts = ["png", "jpg", "jpeg", "PNG", "JPG", "JPEG"];
      if(imageExts.indexOf(ext)>=0){
         htm = '<div class="row"><div class="col-xs-4 no_padding"><img class="pull-left attach-Img '+attachmentFileId+'" src="http://api.quickblox.com/blobs/'+attachmentFileId+"/download.xml?token="+token+'"></div>';  
      }
      else if(ext === "pdf"){         
        htm = '<div class="row"><div class="col-xs-4 no_padding"><img class="pull-left attach-Img '+attachmentFileId+'" src="'+ site_url + "assets/images/pdf.jpg" + '"></div>';  
      }
      else if(ext === "gif"){
        htm = '<div class="row"><div class="col-xs-4 no_padding"><img class="pull-left attach-Img '+attachmentFileId+'" src="'+ site_url + "assets/images/gifs.jpg" + '"></div>';  
      }
      else{
        htm = '<div class="row "><div class="col-xs-4 no_padding"><img class="pull-left attach-Img '+attachmentFileId+'" src="'+ site_url + "assets/images/file.jpg" + '"></div>';  
      }
      htm += '<div class="col-xs-8"><p><a download="download" target="_blank" href="http://api.quickblox.com/blobs/'+attachmentFileId+'/download.xml?token='+token+'" id="'+ attachmentFileId + '" class="wrapword row" style="color:#111;">' + AttachmentFileName + '</a></p><h6 class="wrapword row ' + attachmentFileId + '"></h6></div></div>';
      
      $(".attach-div").append(htm);
}  
  var delivered = '<img class="icon-small" src="assets/images/delivered.jpg" alt="" id="delivered_'+messageId+'">';
  var read = '<img class="icon-small" src="'+site_url+'assets/images/read.jpg" alt="" id="read_'+messageId+'">';
  var parts = messageDateSent.toString().split("GMT");
  var date = getMsgDate(parts[0]);
  var messageHtml;

  if(messageSenderId == currentUser_uid){
    messageHtml = '<div class="row" style="margin:0px;">'+
                    '<div class="col-xs-2">'+
                    '</div>'+
                    '<div class="col-xs-9">'+
                      '<p class="list-group-item-text message-text pull-right Qinput right-msg-style" id = "' + messageId + '">'+(messageAttach ? messageAttach : messageText)+'</p>'+
                    '</div>'+
                    '<div class="col-md-1 col-sm-1 col-xs-1" style="padding:0;">'+
                      '<a href="#" title="'+ messageSenderName +'"><img class="pull-left round" width="30" height="30" src="'+messageSenderPic+'"></a>'+
                    '</div>'+
                  '</div>'+
                  '<div class="row" style="margin:0px 0px 20px 20px;">'+
                    '<div class="col-xs-2"></div>'+
                    '<div class="col-xs-2 light-gray-text">'+
                    '<span class="glyphicon glyphicon-trash pull-left" onclick = "deleteMessage('+ "'" + messageId.toString() +"'" + ')" style = "margin-right:10px;"></span>'+
                    '</div>'+
                    '<div class="col-xs-7">'+
                    '<time datetime="'+messageDateSent+'" class="message-time pull-right '+ messageId + '">'+ date +'</time>'+
                    
                    '</div>'+
                  '</div>';
  
  }
  else{
  messageHtml = '<div class="row" style="margin:0px;">'+    
                  '<div class="col-xs-1" style="padding:0;">'+
                    '<a href="#" title="'+ messageSenderName +'"><img class="round pull-right" width="30" height="30" src="'+messageSenderPic+'"></a>'+
                  '</div>'+
                  '<div class="col-xs-9">'+
                    '<p class="list-group-item-text message-text pull-left Qinput left-msg-style" id="' + messageId + '">'+(messageAttach ? messageAttach : messageText)+'</p>'+
                  '</div>'+  
                  '<div class="col-xs-4">'+
                  '</div>'+
                '</div>'+
                '<div class="row" style="margin:0px 20px 20px 0px;">'+
                  '<div class="col-md-1 col-sm-1 col-xs-1">'+
                  '</div>'+                  
                  '<div class="col-xs-7 pull-left">'+
                  '<time datetime="'+messageDateSent+'" class="message-time pull-left '+ messageId + '">'+ date +'</time>'+
                  '</div>'+
                  '<div class="col-xs-2 light-gray-text" style="padding:0px;">'+
                    '<img src="'+ site_url + "assets/images/rate.png" + '" class="pull-right" onclick="saveMessage('+ "'"+messageSenderId.toString()+"'" + ',' + "'" + messageId.toString() + "'" + ',' + 'this)" style = "margin-left:5px;width:16px;height:16px;"></span>';
                    if(currentUser_type == 1){
                      messageHtml += '<span class="glyphicon glyphicon-trash pull-right" onclick = "deleteMessage('+ "'" + messageId.toString() +"'" + ',' + 'this)" style = "margin-left:10px;"></span>';
                    }
                    messageHtml+='<span class="pull-right" style="padding-left:5px;"></span>'+
                  '</div>'+
                '</div>';

      
  }
  return messageHtml;
}





// build html for dialogs
function buildDialogHtml(dialogId, dialogUnreadMessagesCount, dialogIcon, dialogName, dialogLastMessage) {
  
  var UnreadMessagesCountShow = '<span class="badge">'+dialogUnreadMessagesCount+'</span>';
      UnreadMessagesCountHide = '<span class="badge" style="display: none;">'+dialogUnreadMessagesCount+'</span>';
  if(dialogUnreadMessagesCount > 0){
      if(document.title.indexOf('message') < 0) document.title = "(New message) " + document.title; 
  }
  var dialogHtml = '<a href="'+site_url + 'chat/channel/' + dialogId + '" class="list-group-item inactive" id='+'"'+dialogId+'"'+' onclick="triggerDialog('+"'"+dialogId+"'"+', 1)">'+
                   (dialogUnreadMessagesCount === 0 ? UnreadMessagesCountHide : UnreadMessagesCountShow)+'<h5 class="list-group-item-heading">'+
                   dialogIcon+'&nbsp;&nbsp;&nbsp;<span><strong>'+dialogName+'</strong></span></h5>'+'<p class="list-group-item-text last-message">'+
                   (dialogLastMessage === null ?  "" : dialogLastMessage)+'</p>'+'</a>';
  return dialogHtml;
}

// build html for typing status
function buildTypingUserHtml(userId, userLogin) {
  //var typingUserHtml = '<div id="'+userId+'_typing" class="list-group-item typing">'+'<time class="pull-right">writing now</time>'+'<h4 class="list-group-item-heading">'+
  //                     userLogin+'</h4>'+'<p class="list-group-item-text"> . . . </p>'+'</div>';
  var typingUserHtml;
  if(userLogin !== "undefined") typingUserHtml = '<div id="'+userId+'_typing" class="list-group-item typing">'+'<p style="color:gray;"><marquee><img alt="" src="'+site_url+'assets/images/waiting.png" /></marquee>'+userLogin + '  is typing...</p></div>';
  return typingUserHtml;
}

function buildMetaHtml(jsonData) {
  var jsonObj = JSON.parse(jsonData);
  console.log("###################");
  console.log(jsonObj);
  var retHtml = '<div id="information_holder">'+
    '<h4>'+
      '<span class="">'+jsonObj.d_name+'</span>'+
    '</h4>'+

    '<h5 class="text-muted">Created by '+jsonObj.d_owner+'</h5>'+
    '<div class="information_actions">';
    
    if (jsonObj.notify == "10") {
      retHtml += '<a id="chat-noti" class="text-muted icon-noti-off" onclick="notifyAction(\''+jsonObj.d_id+'\')">Notifications<span class="">OFF</span></a>';
    } else {
      retHtml += '<a id="chat-noti" class="text-muted icon-noti-on" onclick="notifyAction(\''+jsonObj.d_id+'\')">Notifications<span class="">ON</span></a>';
    }
      
  if (jsonObj.d_owner == "Me") {
    retHtml += '<a class="" onclick="deleteAction(\''+jsonObj.d_id+'\')"><span class="text-danger">Delete</span></a>';
  } else {
    retHtml += '<a class="" onclick="leaveAction(\''+jsonObj.d_id+'\')"><span class="text-warning">Leave</span></a>';
  }
    retHtml += '</div><div class="information_members"><h5 class="">'+jsonObj.d_users.length+' Members';
  if (jsonObj.d_owner == "Me" && jsonObj.d_type == "2") {
    retHtml += '<a class="" onclick="addMember(\''+jsonObj.d_id+'\')">+ Add Members</a>';
  }  
    retHtml += '</h5><ul>';
  for (var i=0; i<jsonObj.d_users.length; i++) {
    var d_user = jsonObj.d_users[i];
    var username = '';
    if (d_user.fname) {
        username = d_user.fname+" "+d_user.lname;
    } else {
        var strArr = d_user.email.split("@");
        username = strArr[0];
    }
    if (d_user.photo == "") d_user.photo = site_url + "/assets/images/emp-sm.jpg";
    retHtml += '<li class="" id="remove-'+d_user.id+'"><a class="" href="'+site_url+'/profile/user/'+d_user.id+'"><img class="avatar avatar_small" src="'+d_user.photo+'">' + username+'</a>';;
    
   if (jsonObj.d_owner == "Me") {
    retHtml += '<a class="information_remove_user" onclick="removeAction(\''+jsonObj.d_id+'\', \''+d_user.id+'\', \''+username+'\')"></a>';
  }
    retHtml += '<span class=""><lastseen data-user-id="4513703"><span class="lastseen">offline</span></lastseen></span></li>';
  }
        
  retHtml += '</ul></div></div>';
  return retHtml;
}

// build html for users list
function buildUserHtml(userLogin, userId, isNew) {
  var userHtml = "<a href='#' id='" + userId;
  if(isNew){
    userHtml += "_new'";
  }else{
    userHtml += "'";
  }
  userHtml += " class='col-md-12 col-sm-12 col-xs-12 users_form' onclick='";
  userHtml += "clickToAdd";
  userHtml += "(\"";
  userHtml += userId;
  if(isNew){
    userHtml += "_new";
  }
  userHtml += "\")'>";
  userHtml += userLogin;
  userHtml +="</a>";

  return userHtml;
}
